from Artificial_Neural_Network_Classifier import artificialneuralnetwork_classifier
import pandas as pd
import numpy as np

# lisons les information contenu dans notre tab

df = pd.read_csv('diabetes.csv')
df = df.apply(pd.to_numeric, errors='coerce')
df = df.dropna()

# Selectionnons les colones qui nous intérèsseront comme données de prédiction
x = np.matrix(df[["Glucose",
                  "BloodPressure","SkinThickness",
                  "Insulin","BMI",
                  "DiabetesPedigreeFunction","Age"]].to_numpy() )

# Selectionnons la colones de sortie celle que nous souhaitons prédire
y = np.matrix(df[["Outcome"]].to_numpy())

# Entrainons le model
Ann = artificialneuralnetwork_classifier(x,y)

# Predisons si le patient 2 et 3 on le diabète

X = np.matrix([[85,66,29,0,26.6,0.351,31] ])
print(Ann.predict(X))
X = np.matrix([[183,64,0,0,23.3,0.672,32] ])
print(Ann.predict(X))
